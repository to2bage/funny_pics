INSERT INTO "snippets" VALUES(2,'wwbr','With best regards,
__type your name__','None',2);
INSERT INTO "snippets" VALUES(3,'tthankyou','Dear __Name__,

I wanted to write you a little note to thank you again for the lovely __gift__ you gave to me. It was so incredibly generous of you to give a __gift__ to me for my efforts in organizing the __event__. Thanks again, __Name__. 

Best Wishes,
__My Name__

','None',3);
INSERT INTO "snippets" VALUES(4,'hhello','Hi there!','None',5);
INSERT INTO "tags" VALUES(2,'Email');
INSERT INTO "tags" VALUES(3,'Signature');
INSERT INTO "tags" VALUES(4,'Letter');
INSERT INTO "tags" VALUES(5,'Hello');
INSERT INTO "tagsIndex" VALUES(2,2);
INSERT INTO "tagsIndex" VALUES(3,2);
INSERT INTO "tagsIndex" VALUES(2,3);
INSERT INTO "tagsIndex" VALUES(4,3);
INSERT INTO "tagsIndex" VALUES(5,4);
